package com.bypassvpn.app

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import com.bypassvpn.app.databinding.ActivityMainBinding

class MainActivity : AppCompatActivity() {
    private lateinit var binding: ActivityMainBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        val isDarkTheme = resources.configuration.uiMode and
                android.content.res.Configuration.UI_MODE_NIGHT_MASK ==
                android.content.res.Configuration.UI_MODE_NIGHT_YES

        val gradientBackground = if (isDarkTheme) {
            ContextCompat.getDrawable(this, R.drawable.gradient_purple_black_dark)
        } else {
            ContextCompat.getDrawable(this, R.drawable.gradient_purple_black_light)
        }
        binding.connectButton.background = gradientBackground

        binding.connectButton.text = "BE VPN"
        binding.connectButton.setOnClickListener {
            android.widget.Toast.makeText(this, "Нет подключения", android.widget.Toast.LENGTH_SHORT).show()
        }
    }
}